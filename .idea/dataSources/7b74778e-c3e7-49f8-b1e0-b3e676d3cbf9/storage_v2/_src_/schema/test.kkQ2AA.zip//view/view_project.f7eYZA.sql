create view view_project as
select 1 AS `id`,
       1 AS `name`,
       1 AS `user_id`,
       1 AS `state`,
       1 AS `type`,
       1 AS `target_money`,
       1 AS `current_money`,
       1 AS `create_time`,
       1 AS `end_time`,
       1 AS `purpose`,
       1 AS `cover_story`,
       1 AS `cover`;

