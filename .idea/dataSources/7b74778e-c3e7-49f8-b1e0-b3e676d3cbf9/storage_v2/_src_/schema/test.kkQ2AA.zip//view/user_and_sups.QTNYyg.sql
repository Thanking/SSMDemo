create view user_and_sups as
select 1 AS `user_id`,
       1 AS `project_id`,
       1 AS `project_name`,
       1 AS `target_money`,
       1 AS `current_money`,
       1 AS `state`,
       1 AS `pro_state`,
       1 AS `money`,
       1 AS `date`,
       1 AS `order_id`;

