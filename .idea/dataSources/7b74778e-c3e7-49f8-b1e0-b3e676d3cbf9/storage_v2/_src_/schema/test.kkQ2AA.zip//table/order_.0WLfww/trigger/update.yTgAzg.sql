create definer = root@localhost trigger `update`
    after update
    on order_
    for each row
BEGIN

declare m int;

set m =  new.money;

update project set current_money = m + current_money where id = new.project_id;

update user set money = money - m where id = new.user_id;

update project p set p.state = 31 where p.id = new.project_id and p.current_money >= p.target_money  ;

END;

