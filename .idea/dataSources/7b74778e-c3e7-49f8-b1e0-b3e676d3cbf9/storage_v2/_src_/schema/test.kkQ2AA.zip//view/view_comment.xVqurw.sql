create view view_comment as
select 1 AS `username`, 1 AS `content`, 1 AS `time`, 1 AS `project_id`;

