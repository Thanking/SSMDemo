create view view_support as
select 1 AS `username`, 1 AS `money`, 1 AS `date`, 1 AS `project_id`;

